# Consulta a los Junimos — Android

Proyecto Android nativo (Kotlin + WebView local) que empaqueta la interfaz HTML en la aplicación. La interfaz se carga desde `app/src/main/assets/index.html`, por lo que no necesita internet ni alojamiento HTTPS.

## Abrir y generar el APK
1. Instala Android Studio (versión actual) y el Android SDK Platform 35.
2. Abre esta carpeta (`ConsultaJunimosAndroid`) desde Android Studio.
3. Espera a que termine Gradle Sync.
4. Conecta un Android o crea un emulador y pulsa **Run** para probar.
5. Para generar un APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio mostrará la ubicación del APK generado (normalmente `app/build/outputs/apk/debug/app-debug.apk`).

## Detalles
- Nombre: Consulta a los Junimos
- Identificador: `com.consulta.junimos`
- Orientación: vertical
- SDK mínimo: Android 6.0 (API 23)
- HTML, CSS, JavaScript y sprites integrados localmente.
- Los sorteos son equiprobables: `Math.floor(Math.random() * 5)`.
- El historial usa `localStorage` del WebView y permanece en el dispositivo.

## Nota
Este entorno de trabajo no tiene Android SDK ni Gradle instalados, así que se entrega el proyecto Android listo para abrir y compilar en Android Studio; no se afirma que ya exista un APK compilado.
